# NEXUS ROOT v0.7 — APatch ARM64 patch pipeline

This source contains an APatch/KernelPatch boot-image patch workflow. The APK build workflow compiles the official KernelPatch `kpimg` for Android and `kptools` for Android ARM64, bundles both into the APK, then builds the app.

## Build through GitHub Actions

1. Put `NEXUS_ROOT_SOURCE.zip` at the repository root (the source archive must contain this project at its root).
2. Copy `.github/workflows/build-apk.yml` from this project into the repository at `.github/workflows/build-apk.yml` (replace the previous build workflow).
3. Commit/push both files or run **Actions → Build NEXUS ROOT with APatch tools → Run workflow**.
4. Download the `NEXUS-ROOT-v0.7-APatch-ARM64` artifact from the completed run.

The workflow builds `kpimg-android` and Android `kptools` from the official KernelPatch source. No manual binary selection is required in the app.

## APatch patching

On an ARM64 Android device, choose the original firmware `boot.img`, enter the APatch SuperKey, and run the patch. The app saves `nexus-patched-boot.img`; it does not flash any partition. Keep a copy of the original image and verify the exact partition layout for the device before flashing. APatch's documented workflow patches `boot.img`; it does not mean that `init_boot.img` or `vendor_boot.img` are interchangeable.

APatch/KernelPatch is ARM64-only. This APatch backend does not claim ARM32/x86 support. KernelPatch requires `CONFIG_KALLSYMS=y`; actual device/kernel compatibility must be confirmed before flashing.

## Scope

- Implemented in this version: APatch/KernelPatch boot image file patching on ARM64, with tools bundled by CI.
- Not implemented in this version: automatic flashing, KernelSU patching, Magisk patching, live KPM loading/management, APM runtime, or a universal module installer.
- The GitHub workflow has been authored but has not been executed in this environment. A successful CI run and a real-device patch are still required before calling this release verified.

## Upstream

- KernelPatch build instructions: https://github.com/bmax121/KernelPatch/blob/main/doc/en/build.md
- APatch installation and patching instructions: https://apatch.dev/install.html

KernelPatch is GPL-2.0. Preserve upstream license and notices when redistributing derived binaries/source.
