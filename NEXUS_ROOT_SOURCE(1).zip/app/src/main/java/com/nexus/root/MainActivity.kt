package com.nexus.root

import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

private val Bg = Color(0xFF080D16)
private val Panel = Color(0xFF111B2A)
private val Blue = Color(0xFF39A9FF)
private val Muted = Color(0xFF91A2B8)

private data class ModuleItem(val file: File, val name: String, val version: String, val author: String, val format: String, val description: String)
private data class ImageReport(val name: String, val size: Long, val sha256: String, val magic: String, val header: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }

    private fun moduleDirectory(): File = File(filesDir, "modules").apply { mkdirs() }

    @Composable
    private fun NexusApp() {
        var tab by remember { mutableIntStateOf(0) }
        var notice by remember { mutableStateOf("NEXUS ROOT v0.7 — bundled APatch patch engine") }
        var imageReport by remember { mutableStateOf<ImageReport?>(null) }
        var modules by remember { mutableStateOf(loadModules()) }
        var superKey by remember { mutableStateOf("") }
        var patchBusy by remember { mutableStateOf(false) }
        var pendingPatchedImage by remember { mutableStateOf<File?>(null) }
        val savePatchedPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val source = pendingPatchedImage
            if (uri != null && source != null) runCatching {
                contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
                notice = "Пропатченный образ сохранён"
            }.onFailure { notice = "Ошибка сохранения: ${it.message}" }
        }
        var bootPickerUri by remember { mutableStateOf<Uri?>(null) }
        val bootPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            bootPickerUri = uri
            if (uri != null) inspectBoot(uri) { report, message -> imageReport = report; notice = message }
        }
        val modulePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importModule(uri) { message -> notice = message; modules = loadModules() }
        }

        MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
            Scaffold(containerColor = Bg, bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    val labels = listOf("Главная", "Патчинг", "Модули", "Диагностика")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Build, Icons.Default.Extension, Icons.Default.Tune)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = { Icon(icons[index], label) }, label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, selectedTextColor = Blue, indicatorColor = Color(0xFF193653), unselectedIconColor = Muted, unselectedTextColor = Muted))
                    }
                }
            }) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    when (tab) {
                        0 -> HomeScreen(onPatch = { tab = 1 }, onModules = { tab = 2 })
                        1 -> PatchScreen(imageReport, notice, superKey, patchBusy,
                            onKey = { superKey = it },
                            onPick = { bootPicker.launch(arrayOf("application/octet-stream", "*/*")) },
                            onPatch = {
                                val bootUri = bootPickerUri
                                if (bootUri == null) notice = "Сначала выбери исходный boot.img"
                                else {
                                    patchBusy = true; notice = "Запуск настоящего KernelPatch…"
                                    lifecycleScope.launch {
                                        val result = withContext(Dispatchers.IO) { runCatching { ApPatchEngine(this@MainActivity).patch(bootUri, superKey) { msg -> runOnUiThread { notice = msg.take(500) } } } }
                                        patchBusy = false
                                        result.onSuccess { pendingPatchedImage = it.output; notice = it.log; savePatchedPicker.launch("nexus-patched-boot.img") }
                                            .onFailure { notice = "Патчинг остановлен: ${it.message}" }
                                    }
                                }
                            })
                        2 -> ModulesScreen(modules, notice, onImport = { modulePicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }, onRemove = { item -> item.file.delete(); modules = loadModules(); notice = "Модуль удалён из каталога NEXUS" })
                        else -> ToolsScreen(modules.size)
                    }
                }
            }
        }
    }

    private fun inspectBoot(uri: Uri, done: (ImageReport?, String) -> Unit) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val name = queryName(uri)
                    val digest = MessageDigest.getInstance("SHA-256")
                    val head = ByteArray(4096)
                    var headCount = 0
                    var total = 0L
                    contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Не удалось открыть файл" }
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            if (headCount < head.size) {
                                val copy = minOf(n, head.size - headCount)
                                System.arraycopy(buffer, 0, head, headCount, copy)
                                headCount += copy
                            }
                            digest.update(buffer, 0, n)
                            total += n
                        }
                    }
                    val magic = if (headCount >= 8) String(head, 0, 8, Charsets.US_ASCII) else "Недостаточно данных"
                    val isAndroidBoot = magic.startsWith("ANDROID!")
                    val headerVersion = if (isAndroidBoot && headCount >= 44) {
                        val version = (head[40].toInt() and 0xff) or ((head[41].toInt() and 0xff) shl 8) or ((head[42].toInt() and 0xff) shl 16) or ((head[43].toInt() and 0xff) shl 24)
                        "Поле header_version: $version (предварительное чтение)"
                    } else if (isAndroidBoot) "Заголовок Android boot image обнаружен" else "Сигнатура Android boot image не обнаружена"
                    ImageReport(name, total, digest.digest().joinToString("") { "%02x".format(it) }, magic, headerVersion) to if (isAndroidBoot) "Образ распознан. Создан отчёт анализа; патч ещё не применялся." else "Файл прочитан, но сигнатура boot image не распознана. Патч не выполнялся."
                }.getOrElse { null to "Ошибка анализа: ${it.message ?: "неизвестная ошибка"}" }
            }
            done(result.first, result.second)
        }
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "Выбранный файл"
        }
        return uri.lastPathSegment ?: "Выбранный файл"
    }

    private fun importModule(uri: Uri, done: (String) -> Unit) {
        lifecycleScope.launch {
            val message = withContext(Dispatchers.IO) {
                runCatching {
                    val name = queryName(uri)
                    val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
                    val target = File(moduleDirectory(), "${System.currentTimeMillis()}_$safeName")
                    contentResolver.openInputStream(uri).use { input -> requireNotNull(input).copyTo(target.outputStream()) }
                    val ext = target.extension.lowercase()
                    val format = when {
                        ext == "kpm" -> "KPM"
                        ext == "apm" -> "APM"
                        ext == "nexus" -> "NEXUS"
                        ext == "zip" -> "ZIP / требуется определение"
                        else -> "Неизвестный формат"
                    }
                    if (ext == "zip") {
                        val metadata = runCatching { ZipFile(target).use { zip ->
                            val entry = listOf("module.prop", "nexus-module.properties", "module.json").firstNotNullOfOrNull { zip.getEntry(it) }
                            entry?.let { zip.getInputStream(it).bufferedReader().use { reader -> reader.readText().take(12000) } }.orEmpty()
                        } }.getOrDefault("")
                        if (metadata.contains("id=") || metadata.contains("id\"")) "ZIP-модуль импортирован; метаданные найдены. Совместимость и установка не подтверждены." else "ZIP сохранён в каталоге модулей; файл метаданных не найден."
                    } else "$format-файл добавлен в каталог модулей. Проверка совместимости и загрузка в ядро пока не реализованы."
                }.getOrElse { "Импорт не выполнен: ${it.message}" }
            }
            done(message)
        }
    }

    private fun loadModules(): List<ModuleItem> = moduleDirectory().listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }?.map { file ->
        val ext = file.extension.uppercase()
        ModuleItem(file, file.name, "—", "—", if (ext in listOf("KPM", "APM", "NEXUS")) ext else "ZIP / неизвестен", "Файл хранится локально; установка не выполнялась")
    } ?: emptyList()

    @Composable private fun Header(subtitle: String) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
            Text("NEXUS ROOT", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }

    @Composable private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel), content = content)
    }

    @Composable private fun InfoLine(label: String, value: String) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Muted, fontSize = 12.sp); Spacer(Modifier.width(12.dp)); Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }

    @Composable private fun HomeScreen(onPatch: () -> Unit, onModules: () -> Unit) {
        LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
            item { Header("UNIVERSAL ANDROID ROOT PLATFORM • v0.6") }
            item { Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Shield, null, tint = Blue, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(10.dp)); Column { Text("Состояние Root Engine", fontWeight = FontWeight.SemiBold); Text("Не установлен / не активен", color = Muted, fontSize = 12.sp) } }
                    HorizontalDivider(color = Color(0xFF26364B)); Text("NEXUS ROOT включает реальный APatch/KernelPatch boot-image patch pipeline при наличии официальных бинарников kptools и kpimg. Другие Root Engine подключаются отдельными backend-модулями.", color = Muted, fontSize = 12.sp)
                } }
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Устройство", fontWeight = FontWeight.Bold); InfoLine("Модель", "${Build.MANUFACTURER} ${Build.MODEL}"); InfoLine("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"); InfoLine("ABI", Build.SUPPORTED_ABIS.joinToString())
                } }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionCard("Патчинг", "Анализ boot-образа", Icons.Default.Build, Modifier.weight(1f), onPatch)
                    ActionCard("Модули", "Импорт и каталог", Icons.Default.Extension, Modifier.weight(1f), onModules)
                }
                PanelCard { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Целевая совместимость", fontWeight = FontWeight.Bold); InfoLine("Архитектуры", "ARM32 · ARM64 · x86 · x86_64"); InfoLine("Ядра", "GKI · Non-GKI"); InfoLine("Форматы", "NEXUS · APM · KPM"); InfoLine("Цель ядра", "Linux 5.10+") } }
            } }
        }
    }

    @Composable private fun ActionCard(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
        PanelCard { Column(modifier.clickable(onClick = onClick).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, null, tint = Blue); Text(title, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 10.sp) } }
    }

    @Composable private fun PatchScreen(report: ImageReport?, notice: String, superKey: String, busy: Boolean, onKey: (String) -> Unit, onPick: () -> Unit, onPatch: () -> Unit) {
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item { Header("Boot image • Patch File / Direct Patch") }
            item { Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("PATCH FILE", color = Blue, fontWeight = FontWeight.Black); Text("Выбери оригинальный boot.img из прошивки. NEXUS проверит сигнатуру и SHA-256, затем выполнит APatch-патчинг.", color = Muted, fontSize = 12.sp)
                    Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Выбрать исходный boot.img") }
                    Text("KernelPatch tools: встроенные в APK (ARM64)", color = Muted, fontSize = 11.sp)
                    OutlinedTextField(value = superKey, onValueChange = onKey, modifier = Modifier.fillMaxWidth(), label = { Text("APatch SuperKey (8–63 буквы/цифры)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii))
                    Button(onClick = onPatch, enabled = !busy && report != null, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Выполняется патчинг…" else "НАСТОЯЩИЙ APATCH BOOT PATCH") }
                    report?.let { HorizontalDivider(color = Color(0xFF26364B)); Text("ОТЧЁТ АНАЛИЗА", color = Blue, fontWeight = FontWeight.Bold); InfoLine("Файл", it.name); InfoLine("Размер", "${it.size} байт"); InfoLine("Сигнатура", it.magic); Text(it.header, color = Muted, fontSize = 11.sp); Text("SHA-256", color = Muted, fontSize = 11.sp); Text(it.sha256, color = Color.White, fontSize = 10.sp) }
                } }
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("DIRECT PATCH", color = Blue, fontWeight = FontWeight.Black); Text("Прямое изменение разделов устройства отключено: в этой версии нет проверенного root-backend, карты разделов и механизма восстановления.", color = Muted, fontSize = 12.sp)
                    Text("Патчинг создаёт отдельный nexus-patched-boot.img. Автоматическая запись во flash-раздел не выполняется.", color = Color(0xFFFFC36B), fontSize = 12.sp)
                } }
                Text(notice, color = Muted, fontSize = 11.sp)
            } }
        }
    }

    @Composable private fun ModulesScreen(modules: List<ModuleItem>, notice: String, onImport: () -> Unit, onRemove: (ModuleItem) -> Unit) {
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item { Header("Менеджер модулей • NEXUS / APM / KPM") }
            item { Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Локальный каталог модулей", fontWeight = FontWeight.Bold); Text("Импортируй пакет для хранения в приложении. Формат определяется по расширению; это ещё не означает, что модуль совместим с ядром или может быть установлен.", color = Muted, fontSize = 12.sp)
                    Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Импортировать модуль") }
                    Text(notice, color = Muted, fontSize = 11.sp)
                } }
                if (modules.isEmpty()) PanelCard { Text("Каталог пуст. Добавь файл NEXUS, APM, KPM или ZIP-пакет.", Modifier.padding(18.dp), color = Muted, fontSize = 12.sp) }
            } }
            items(modules, key = { it.file.name }) { item ->
                Column(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    PanelCard { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Extension, null, tint = Blue); Spacer(Modifier.width(8.dp)); Text(item.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(item.format, color = Blue, fontSize = 10.sp) }
                        InfoLine("Размер", "${item.file.length()} байт"); Text(item.description, color = Muted, fontSize = 11.sp)
                        TextButton(onClick = { onRemove(item) }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(5.dp)); Text("Удалить из каталога") }
                    } }
                }
            }
            item { Column(Modifier.padding(16.dp)) { Text("Runtime / установка", color = Blue, fontWeight = FontWeight.Bold); Text("Загрузка KPM/APM в ядро и установка NEXUS-модулей пока не подключены. Для этого нужны спецификации форматов и отдельные backend-компоненты под конкретные ядра.", color = Muted, fontSize = 12.sp) } }
        }
    }

    @Composable private fun ToolsScreen(moduleCount: Int) {
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item { Header("Диагностика и сведения") }
            item { Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Сведения об Android", fontWeight = FontWeight.Bold); InfoLine("Производитель", Build.MANUFACTURER); InfoLine("Модель", Build.MODEL); InfoLine("Устройство", Build.DEVICE); InfoLine("Продукт", Build.PRODUCT); InfoLine("Android", Build.VERSION.RELEASE); InfoLine("SDK", Build.VERSION.SDK_INT.toString()); InfoLine("ABI", Build.SUPPORTED_ABIS.joinToString())
                } }
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Компоненты", fontWeight = FontWeight.Bold); InfoLine("Boot image inspector", "Доступен"); InfoLine("SHA-256", "Доступен"); InfoLine("Локальный каталог", "$moduleCount модулей"); InfoLine("Root Engine", "Backend adapters"); InfoLine("APatch boot patch", "Встроенный ARM64 backend"); InfoLine("KPM/APM runtime", "В разработке"); InfoLine("Direct Patch", "Отключён")
                } }
            } }
        }
    }
}
