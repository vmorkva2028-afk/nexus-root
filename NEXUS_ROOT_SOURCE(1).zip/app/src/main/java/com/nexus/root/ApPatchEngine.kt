package com.nexus.root

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest

/** Real APatch/KernelPatch boot-image patch pipeline.
 * Requires an Android-executable kptools matching the device ABI and official kpimg-android.
 * It creates an output image only; flashing is deliberately a separate, explicit operation.
 */
class ApPatchEngine(private val context: Context) {
    data class Result(val output: File, val log: String)

    fun patch(
        bootUri: Uri,
        superKey: String,
        progress: (String) -> Unit = {}
    ): Result {
        require(superKey.length in 8..63 && superKey.all { it.isLetterOrDigit() }) {
            "SuperKey APatch: 8–63 букв и цифр, без спецсимволов"
        }
        require(android.os.Build.SUPPORTED_ABIS.any { it == "arm64-v8a" }) {
            "Официальный APatch/KernelPatch patcher поддерживает только ARM64"
        }
        val work = File(context.cacheDir, "apatch-${System.currentTimeMillis()}").apply { mkdirs() }
        val boot = copyUri(bootUri, File(work, "boot.img"))
        // kptools is packaged as an Android ARM64 executable in jniLibs; kpimg is bundled as an asset.
        val bundledTool = File(context.applicationInfo.nativeLibraryDir, "libkptools.so")
        require(bundledTool.isFile && bundledTool.canExecute()) {
            "В APK нет Android kptools. Установи APK, собранный GitHub Actions с KernelPatch tools."
        }
        val tool = bundledTool
        val kpimg = File(work, "kpimg-android")
        context.assets.open("kpimg-android").use { input -> kpimg.outputStream().use { output -> input.copyTo(output) } }
        require(boot.length() > 4096) { "Boot image слишком маленький" }
        require(kpimg.length() > 4096) { "В APK не найден корректный kpimg-android" }

        progress("Проверка kptools…")
        runTool(work, tool, listOf("--help"), progress, allowHelpFailure = true)
        progress("Распаковка boot.img…")
        runTool(work, tool, listOf("unpack", boot.name), progress)

        // KernelPatch kptools unpack writes the extracted kernel in the working directory.
        val extracted = listOf(File(work, "kernel"), File(work, "kernel-b"))
            .firstOrNull { it.isFile && it.length() > 4096 }
            ?: error("kptools не создал kernel/kernel-b. Образ может быть неподдерживаемого формата.")
        val kernelInput = File(work, "kernel-b")
        if (extracted != kernelInput) extracted.copyTo(kernelInput, overwrite = true)

        progress("Патчинг ядра KernelPatch…")
        runTool(work, tool, listOf("-p", "--image", kernelInput.name, "--skey", superKey,
            "--kpimg", kpimg.name, "--out", "kernel"), progress)
        require(File(work, "kernel").isFile && File(work, "kernel").length() > 4096) {
            "kptools не создал пропатченное ядро"
        }

        progress("Сборка нового boot.img…")
        runTool(work, tool, listOf("repack", boot.name), progress)
        val output = File(work, "new-boot.img")
        require(output.isFile && output.length() > 4096) { "kptools не создал new-boot.img" }
        val hash = sha256(output)
        progress("Готово. SHA-256: $hash")
        return Result(output, "APatch KernelPatch: boot.img распакован, ядро пропатчено и образ пересобран. SHA-256: $hash")
    }

    private fun copyUri(uri: Uri, target: File): File {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Не удалось открыть выбранный файл" }
            target.outputStream().use { output -> input.copyTo(output) }
        }
        return target
    }

    private fun runTool(
        work: File, tool: File, args: List<String>, progress: (String) -> Unit,
        allowHelpFailure: Boolean = false
    ) {
        val command = listOf(tool.absolutePath) + args
        val process = ProcessBuilder(command).directory(work).redirectErrorStream(true).start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        val code = process.waitFor()
        if (output.isNotBlank()) progress(output.take(3000))
        if (code != 0 && !allowHelpFailure) error("Команда ${args.first()} завершилась с кодом $code: ${output.take(1500)}")
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
