# NEXUS ROOT v0.9 — APatch boot image patch workflow

## Boot image patching (real KernelPatch pipeline)

The Patch screen performs the documented APatch / KernelPatch sequence on an Android ARM64 device:

1. The user selects an original Android `boot.img` using the system file picker.
2. NEXUS checks the Android boot magic and copies the original into its private work directory.
3. The app runs the Android ARM64 `kptools` executable bundled by GitHub Actions and extracts the kernel.
4. The extracted kernel is preserved as `kernel-b` and patched using the official `-p --image ... --skey ... --kpimg ... --out kernel` command.
5. `kptools repack boot.img` creates `new-boot.img`.
6. NEXUS checks that the output exists, has an Android boot header, and differs from the original, then opens the system save dialog.

A 32-character alphanumeric APatch SuperKey is generated and stored in the app's private preferences on first launch. The user can edit it. Keep this key: it is required for APatch authentication. The original image is not modified and no partition is flashed automatically.

## Current limits

- Boot image patch backend: APatch / KernelPatch, ARM64 only.
- This is not a Magisk boot patcher or a KernelSU boot patcher. Those require their own backend flows.
- `vendor_boot`, `recovery`, `init_boot`, non-Android boot formats, ARM32, x86 and x86_64 are not claimed as supported by this patch backend.
- The APK must be built with the repository workflow, which builds the official KernelPatch ARM64 `kptools` executable and `kpimg-android` assets.
- The output image is saved by the user. Flashing is deliberately separate to avoid accidental device bricking.

## Build

Upload `NEXUS_ROOT_SOURCE.zip` to the repository root and run `.github/workflows/build-apk.yml` from GitHub Actions. The workflow builds a debug APK artifact. A successful CI build does not replace testing with the target device's exact boot image; always keep the original image and a recovery path.
