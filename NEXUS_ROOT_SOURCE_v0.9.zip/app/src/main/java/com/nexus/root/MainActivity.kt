package com.nexus.root

import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom

private val Bg = Color(0xFF080D16)
private val Panel = Color(0xFF111B2A)
private val Blue = Color(0xFF39A9FF)
private val Muted = Color(0xFF91A2B8)

private data class ModuleItem(val file: File, val name: String, val version: String, val author: String, val format: String, val description: String)
private data class ImageReport(val name: String, val size: Long, val sha256: String, val magic: String, val header: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }

    private fun moduleDirectory(): File = File(filesDir, "modules").apply { mkdirs() }

    @Composable
    private fun NexusApp() {
        var tab by remember { mutableIntStateOf(0) }
        var notice by remember { mutableStateOf("NEXUS ROOT v0.8 — native root adapters") }
        var rootStatus by remember { mutableStateOf("Проверка root-доступа…") }
        var rootModules by remember { mutableStateOf(emptyList<RootManager.Module>()) }
        LaunchedEffect(Unit) {
            val snapshot = withContext(Dispatchers.IO) { RootManager.detect() to RootManager.installedModules() }
            rootStatus = snapshot.first.detail
            rootModules = snapshot.second
        }
        var imageReport by remember { mutableStateOf<ImageReport?>(null) }
        var modules by remember { mutableStateOf(loadModules()) }
        var superKey by remember { mutableStateOf(loadOrCreateSuperKey()) }
        var patchBusy by remember { mutableStateOf(false) }
        var pendingPatchedImage by remember { mutableStateOf<File?>(null) }
        val savePatchedPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val source = pendingPatchedImage
            if (uri != null && source != null) runCatching {
                requireNotNull(contentResolver.openOutputStream(uri)) { "Не удалось создать файл назначения" }.use { out -> source.inputStream().use { it.copyTo(out) } }
                notice = "Пропатченный образ сохранён"
            }.onFailure { notice = "Ошибка сохранения: ${it.message}" }
        }
        var bootPickerUri by remember { mutableStateOf<Uri?>(null) }
        val bootPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            bootPickerUri = uri
            if (uri != null) inspectBoot(uri) { report, message -> imageReport = report; notice = message }
        }
        val modulePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importModule(uri) { message ->
                notice = message
                modules = loadModules()
                lifecycleScope.launch {
                    val snapshot = withContext(Dispatchers.IO) { RootManager.detect() to RootManager.installedModules() }
                    rootStatus = snapshot.first.detail
                    rootModules = snapshot.second
                }
            }
        }

        MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
            Scaffold(containerColor = Bg, bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    val labels = listOf("Главная", "Патчинг", "Модули", "Диагностика")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Build, Icons.Default.Extension, Icons.Default.Tune)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = { Icon(icons[index], label) }, label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, selectedTextColor = Blue, indicatorColor = Color(0xFF193653), unselectedIconColor = Muted, unselectedTextColor = Muted))
                    }
                }
            }) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    when (tab) {
                        0 -> HomeScreen(rootStatus, onPatch = { tab = 1 }, onModules = { tab = 2 })
                        1 -> PatchScreen(imageReport, notice, superKey, patchBusy,
                            onKey = { superKey = it; getSharedPreferences("nexus_patch", MODE_PRIVATE).edit().putString("superkey", it).apply() },
                            onPick = { bootPicker.launch(arrayOf("application/octet-stream", "*/*")) },
                            onPatch = {
                                val bootUri = bootPickerUri
                                if (bootUri == null) notice = "Сначала выбери исходный boot.img"
                                else {
                                    patchBusy = true; notice = "Запуск настоящего KernelPatch…"
                                    lifecycleScope.launch {
                                        val keyForPatch = superKey.ifBlank { createAndStoreSuperKey().also { superKey = it } }
                                        val result = withContext(Dispatchers.IO) { runCatching { ApPatchEngine(this@MainActivity).patch(bootUri, keyForPatch) { msg -> runOnUiThread { notice = msg.take(900) } } } }
                                        patchBusy = false
                                        result.onSuccess { pendingPatchedImage = it.output; notice = it.log; savePatchedPicker.launch("nexus-patched-boot.img") }
                                            .onFailure { notice = "Патчинг остановлен: ${it.message}" }
                                    }
                                }
                            })
                        2 -> ModulesScreen(modules, rootModules, notice,
                            onImport = { modulePicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                            onRemove = { item -> item.file.delete(); modules = loadModules(); notice = "Архив удалён из локального каталога" },
                            onToggle = { item, enabled -> lifecycleScope.launch {
                                val result = withContext(Dispatchers.IO) { RootManager.setModuleEnabled(item.id, enabled) }
                                notice = result.output
                                rootModules = withContext(Dispatchers.IO) { RootManager.installedModules() }
                            } },
                            onUninstall = { item -> lifecycleScope.launch {
                                val result = withContext(Dispatchers.IO) { RootManager.uninstallModule(item.id) }
                                notice = result.output
                                rootModules = withContext(Dispatchers.IO) { RootManager.installedModules() }
                            } })
                        else -> ToolsScreen(modules.size)
                    }
                }
            }
        }
    }

    private fun loadOrCreateSuperKey(): String {
        val prefs = getSharedPreferences("nexus_patch", MODE_PRIVATE)
        return prefs.getString("superkey", null) ?: createAndStoreSuperKey()
    }

    private fun createAndStoreSuperKey(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
        val random = SecureRandom()
        val key = buildString { repeat(32) { append(alphabet[random.nextInt(alphabet.length)]) } }
        getSharedPreferences("nexus_patch", MODE_PRIVATE).edit().putString("superkey", key).apply()
        return key
    }

    private fun inspectBoot(uri: Uri, done: (ImageReport?, String) -> Unit) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val name = queryName(uri)
                    val digest = MessageDigest.getInstance("SHA-256")
                    val head = ByteArray(4096)
                    var headCount = 0
                    var total = 0L
                    contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Не удалось открыть файл" }
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            if (headCount < head.size) {
                                val copy = minOf(n, head.size - headCount)
                                System.arraycopy(buffer, 0, head, headCount, copy)
                                headCount += copy
                            }
                            digest.update(buffer, 0, n)
                            total += n
                        }
                    }
                    val magic = if (headCount >= 8) String(head, 0, 8, Charsets.US_ASCII) else "Недостаточно данных"
                    val isAndroidBoot = magic.startsWith("ANDROID!")
                    val headerVersion = if (isAndroidBoot && headCount >= 44) {
                        val version = (head[40].toInt() and 0xff) or ((head[41].toInt() and 0xff) shl 8) or ((head[42].toInt() and 0xff) shl 16) or ((head[43].toInt() and 0xff) shl 24)
                        "Поле header_version: $version (предварительное чтение)"
                    } else if (isAndroidBoot) "Заголовок Android boot image обнаружен" else "Сигнатура Android boot image не обнаружена"
                    ImageReport(name, total, digest.digest().joinToString("") { "%02x".format(it) }, magic, headerVersion) to if (isAndroidBoot) "Образ распознан. Создан отчёт анализа; патч ещё не применялся." else "Файл прочитан, но сигнатура boot image не распознана. Патч не выполнялся."
                }.getOrElse { null to "Ошибка анализа: ${it.message ?: "неизвестная ошибка"}" }
            }
            done(result.first, result.second)
        }
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "Выбранный файл"
        }
        return uri.lastPathSegment ?: "Выбранный файл"
    }

    private fun importModule(uri: Uri, done: (String) -> Unit) {
        lifecycleScope.launch {
            val message = withContext(Dispatchers.IO) {
                runCatching {
                    val name = queryName(uri)
                    val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
                    val target = File(moduleDirectory(), "${System.currentTimeMillis()}_$safeName")
                    contentResolver.openInputStream(uri).use { input -> requireNotNull(input).copyTo(target.outputStream()) }
                    val ext = target.extension.lowercase()
                    val format = when {
                        ext == "kpm" -> "KPM"
                        ext == "apm" -> "APM"
                        ext == "nexus" -> "NEXUS"
                        ext == "zip" -> "ZIP / требуется определение"
                        else -> "Неизвестный формат"
                    }
                    if (ext == "zip") {
                        val install = RootManager.installModule(target)
                        if (install.ok) "Модуль передан штатному установщику ${RootManager.detect().engine}.\n${install.output}" else "Установка не выполнена. Файл оставлен в локальном каталоге.\n${install.output}"
                    } else if (ext == "kpm") {
                        "KPM сохранён отдельно. APatch KPM можно загружать/встраивать только через поддерживаемый KernelPatch/APatch интерфейс; этот файл не выдаётся за установленный модуль."
                    } else if (ext == "apm" || ext == "nexus") {
                        "Файл сохранён. Для установки нужен ZIP-пакет с module.prop и скриптами, совместимый с выбранным движком."
                    } else "Файл сохранён локально; формат установки не распознан."
                }.getOrElse { "Импорт не выполнен: ${it.message}" }
            }
            done(message)
        }
    }

    private fun loadModules(): List<ModuleItem> = moduleDirectory().listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }?.map { file ->
        val ext = file.extension.uppercase()
        ModuleItem(file, file.name, "—", "—", if (ext in listOf("KPM", "APM", "NEXUS")) ext else "ZIP / неизвестен", "Локальная копия архива")
    } ?: emptyList()

    @Composable private fun Header(subtitle: String) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
            Text("NEXUS ROOT", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }

    @Composable private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel), content = content)
    }

    @Composable private fun InfoLine(label: String, value: String) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Muted, fontSize = 12.sp); Spacer(Modifier.width(12.dp)); Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }

    @Composable private fun HomeScreen(rootStatus: String, onPatch: () -> Unit, onModules: () -> Unit) {
        LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
            item { Header("UNIVERSAL ANDROID ROOT PLATFORM • v0.6") }
            item { Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Shield, null, tint = Blue, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(10.dp)); Column { Text("Состояние Root Engine", fontWeight = FontWeight.SemiBold); Text(rootStatus, color = if (rootStatus.contains("подтверждён")) Color(0xFF75D69A) else Muted, fontSize = 12.sp) } }
                    HorizontalDivider(color = Color(0xFF26364B)); Text("NEXUS ROOT обнаруживает APatch, KernelSU или Magisk через реальный su-доступ и передаёт ZIP-модули штатному установщику найденного движка. Патчинг boot.img пока отдельный APatch ARM64 backend.", color = Muted, fontSize = 12.sp)
                } }
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Устройство", fontWeight = FontWeight.Bold); InfoLine("Модель", "${Build.MANUFACTURER} ${Build.MODEL}"); InfoLine("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"); InfoLine("ABI", Build.SUPPORTED_ABIS.joinToString())
                } }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionCard("Патчинг", "Анализ boot-образа", Icons.Default.Build, Modifier.weight(1f), onPatch)
                    ActionCard("Модули", "Импорт и каталог", Icons.Default.Extension, Modifier.weight(1f), onModules)
                }
                PanelCard { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Целевая совместимость", fontWeight = FontWeight.Bold); InfoLine("Архитектуры", "ARM32 · ARM64 · x86 · x86_64"); InfoLine("Ядра", "GKI · Non-GKI"); InfoLine("Форматы", "NEXUS · APM · KPM"); InfoLine("Цель ядра", "Linux 5.10+") } }
            } }
        }
    }

    @Composable private fun ActionCard(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
        PanelCard { Column(modifier.clickable(onClick = onClick).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, null, tint = Blue); Text(title, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 10.sp) } }
    }

    @Composable private fun PatchScreen(report: ImageReport?, notice: String, superKey: String, busy: Boolean, onKey: (String) -> Unit, onPick: () -> Unit, onPatch: () -> Unit) {
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item { Header("Boot image • Patch File / Direct Patch") }
            item { Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("PATCH FILE", color = Blue, fontWeight = FontWeight.Black); Text("Выбери оригинальный boot.img. Нажми кнопку — NEXUS распакует образ, пропатчит ядро официальным KernelPatch и соберёт отдельный новый boot.img.", color = Muted, fontSize = 12.sp)
                    Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Выбрать исходный boot.img") }
                    Text("Встроенные KernelPatch tools • ARM64", color = Muted, fontSize = 11.sp)
                    OutlinedTextField(value = superKey, onValueChange = onKey, modifier = Modifier.fillMaxWidth(), label = { Text("APatch SuperKey (сохранён на устройстве)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii))
                    Text("Сохрани SuperKey: он понадобится для авторизации APatch после установки пропатченного образа.", color = Color(0xFFFFC36B), fontSize = 11.sp)
                    Button(onClick = onPatch, enabled = !busy && report != null, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "РАСПАКОВКА → ПАТЧИНГ → СБОРКА…" else "ПРОПАТЧИТЬ BOOT.IMG") }
                    report?.let { HorizontalDivider(color = Color(0xFF26364B)); Text("ОТЧЁТ АНАЛИЗА", color = Blue, fontWeight = FontWeight.Bold); InfoLine("Файл", it.name); InfoLine("Размер", "${it.size} байт"); InfoLine("Сигнатура", it.magic); Text(it.header, color = Muted, fontSize = 11.sp); Text("SHA-256", color = Muted, fontSize = 11.sp); Text(it.sha256, color = Color.White, fontSize = 10.sp) }
                } }
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("DIRECT PATCH", color = Blue, fontWeight = FontWeight.Black); Text("Прямое изменение разделов устройства отключено: в этой версии нет проверенного root-backend, карты разделов и механизма восстановления.", color = Muted, fontSize = 12.sp)
                    Text("После успешной проверки Android boot header и SHA-256 приложение предложит сохранить nexus-patched-boot.img. Автоматической прошивки раздела нет.", color = Color(0xFFFFC36B), fontSize = 12.sp)
                } }
                Text(notice, color = Muted, fontSize = 11.sp)
            } }
        }
    }

    @Composable private fun ModulesScreen(modules: List<ModuleItem>, installed: List<RootManager.Module>, notice: String, onImport: () -> Unit, onRemove: (ModuleItem) -> Unit, onToggle: (RootManager.Module, Boolean) -> Unit, onUninstall: (RootManager.Module) -> Unit) {
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item { Header("Менеджер модулей • NEXUS / APM / KPM") }
            item { Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Локальный каталог модулей", fontWeight = FontWeight.Bold); Text("ZIP-пакет передаётся штатному установщику обнаруженного движка: APatch apd, KernelSU ksud или Magisk CLI. Для установки требуется выданный NEXUS ROOT root-доступ.", color = Muted, fontSize = 12.sp)
                    Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Импортировать модуль") }
                    Text(notice, color = Muted, fontSize = 11.sp)
                } }
                Text("УСТАНОВЛЕННЫЕ МОДУЛИ • /data/adb/modules", color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                if (installed.isEmpty()) PanelCard { Text("Установленные модули не найдены или root-доступ не выдан.", Modifier.padding(18.dp), color = Muted, fontSize = 12.sp) }
            } }
            items(installed, key = { it.id }) { item ->
                Column(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    PanelCard { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(item.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        InfoLine("ID", item.id); InfoLine("Версия", item.version.ifBlank { "—" }); InfoLine("Состояние", item.state)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { onToggle(item, item.state != "Включён") }) { Text(if (item.state == "Включён") "Отключить" else "Включить") }
                            TextButton(onClick = { onUninstall(item) }) { Text("Удалить") }
                        }
                    } }
                }
            }
            item { Text("ЛОКАЛЬНЫЕ АРХИВЫ", Modifier.padding(start = 18.dp, top = 14.dp), color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            items(modules, key = { it.file.name }) { item ->
                Column(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    PanelCard { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Extension, null, tint = Blue); Spacer(Modifier.width(8.dp)); Text(item.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(item.format, color = Blue, fontSize = 10.sp) }
                        InfoLine("Размер", "${item.file.length()} байт"); Text(item.description, color = Muted, fontSize = 11.sp)
                        TextButton(onClick = { onRemove(item) }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(5.dp)); Text("Удалить из каталога") }
                    } }
                }
            }
            item { Column(Modifier.padding(16.dp)) { Text("Runtime / установка", color = Blue, fontWeight = FontWeight.Bold); Text("ZIP: штатная установка через root-движок. APM: каталог и скриптовая совместимость APatch. KPM: отдельная операция KernelPatch; обычная установка ZIP к KPM неприменима. NEXUS proprietary runtime ещё не реализован.", color = Muted, fontSize = 12.sp) } }
        }
    }

    @Composable private fun ToolsScreen(moduleCount: Int) {
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item { Header("Диагностика и сведения") }
            item { Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Сведения об Android", fontWeight = FontWeight.Bold); InfoLine("Производитель", Build.MANUFACTURER); InfoLine("Модель", Build.MODEL); InfoLine("Устройство", Build.DEVICE); InfoLine("Продукт", Build.PRODUCT); InfoLine("Android", Build.VERSION.RELEASE); InfoLine("SDK", Build.VERSION.SDK_INT.toString()); InfoLine("ABI", Build.SUPPORTED_ABIS.joinToString())
                } }
                PanelCard { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Компоненты", fontWeight = FontWeight.Bold); InfoLine("Boot image inspector", "Доступен"); InfoLine("SHA-256", "Доступен"); InfoLine("Локальный каталог", "$moduleCount модулей"); InfoLine("Root Engine", "Backend adapters"); InfoLine("APatch boot patch", "Встроенный ARM64 backend"); InfoLine("KPM/APM runtime", "В разработке"); InfoLine("Direct Patch", "Отключён")
                } }
            } }
        }
    }
}
