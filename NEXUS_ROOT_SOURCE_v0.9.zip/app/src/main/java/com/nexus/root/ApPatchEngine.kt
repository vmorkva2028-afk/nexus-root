package com.nexus.root

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * APatch / KernelPatch boot image patcher.
 * Uses the official kptools unpack -> patch -> repack flow.
 * It only writes a new image to app storage; it never flashes a partition.
 */
class ApPatchEngine(private val context: Context) {
    data class Result(val output: File, val log: String, val sha256: String)

    fun patch(bootUri: Uri, superKey: String, progress: (String) -> Unit = {}): Result {
        require(superKey.length in 8..63 && superKey.all { it in 'A'..'Z' || it in 'a'..'z' || it in '0'..'9' }) {
            "SuperKey должен содержать 8–63 латинских букв и цифр"
        }
        require(android.os.Build.SUPPORTED_ABIS.any { it == "arm64-v8a" }) {
            "Этот APK содержит только ARM64 kptools. Для этого устройства нужна сборка под ARM64."
        }

        val work = File(context.cacheDir, "nexus-bootpatch-${System.currentTimeMillis()}").apply { mkdirs() }
        val boot = copyUri(bootUri, File(work, "boot.img"))
        require(boot.length() > 4096) { "Файл слишком маленький для boot.img" }
        require(readMagic(boot) == "ANDROID!") {
            "Это не Android boot.img (нет сигнатуры ANDROID!). Выбери исходный boot.img, не recovery/vendor_boot."
        }

        // The CI packages the official Android ARM64 kptools executable under this name.
        val tool = File(context.applicationInfo.nativeLibraryDir, "libkptools.so")
        require(tool.isFile && tool.canExecute()) {
            "В APK отсутствует исполняемый kptools. Пересобери APK через актуальный GitHub Actions workflow."
        }
        val kpimg = File(work, "kpimg-android")
        context.assets.open("kpimg-android").use { input -> kpimg.outputStream().use(input::copyTo) }
        require(kpimg.length() > 4096) { "В APK отсутствует корректный kpimg-android" }

        progress("Проверка KernelPatch tools…")
        runTool(work, tool, listOf("--version"), progress)

        progress("Распаковка исходного boot.img…")
        runTool(work, tool, listOf("unpack", boot.name), progress)

        // Official APatch instructions: unpack creates `kernel`; patch that kernel into `kernel`.
        val unpackedKernel = File(work, "kernel")
        require(unpackedKernel.isFile && unpackedKernel.length() > 4096) {
            "kptools не извлёк kernel из boot.img. Образ может использовать неподдерживаемый формат или заголовок."
        }
        val originalKernel = File(work, "kernel-b")
        unpackedKernel.copyTo(originalKernel, overwrite = true)
        val originalKernelHash = sha256(originalKernel)

        progress("Патчинг ядра APatch / KernelPatch…")
        runTool(
            work,
            tool,
            listOf("-p", "--image", originalKernel.name, "--skey", superKey,
                "--kpimg", kpimg.name, "--out", "kernel"),
            progress
        )

        val patchedKernel = File(work, "kernel")
        require(patchedKernel.isFile && patchedKernel.length() > 4096) {
            "KernelPatch завершился без ошибки, но пропатченное ядро не создано"
        }
        require(sha256(patchedKernel) != originalKernelHash) {
            "Ядро после патчинга не изменилось. Новый boot.img не создан."
        }

        progress("Пересборка нового boot.img…")
        runTool(work, tool, listOf("repack", boot.name), progress)

        val output = File(work, "new-boot.img")
        require(output.isFile && output.length() > 4096) {
            "kptools не создал new-boot.img. Проверь формат исходного образа."
        }
        require(readMagic(output) == "ANDROID!") {
            "Пересобранный файл не прошёл проверку заголовка Android boot image."
        }
        val outputHash = sha256(output)
        require(outputHash != sha256(boot)) { "Итоговый boot.img совпадает с исходным — патч не подтверждён." }

        progress("Патчинг завершён. Проверка SHA-256 пройдена.")
        return Result(
            output,
            "ГОТОВО: APatch / KernelPatch создал новый boot.img.\n" +
                "Размер: ${output.length()} байт\nSHA-256: $outputHash\n" +
                "Исходный файл не изменялся. Образ не прошивался.",
            outputHash
        )
    }

    private fun copyUri(uri: Uri, target: File): File {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Не удалось открыть выбранный файл" }
            target.outputStream().use { output -> input.copyTo(output) }
        }
        return target
    }

    private fun readMagic(file: File): String = file.inputStream().use { input ->
        val bytes = ByteArray(8)
        val count = input.read(bytes)
        if (count == 8) String(bytes, Charsets.US_ASCII) else ""
    }

    private fun runTool(work: File, tool: File, args: List<String>, progress: (String) -> Unit) {
        val logFile = File(work, "kptools-${System.nanoTime()}.log")
        val process = ProcessBuilder(listOf(tool.absolutePath) + args)
            .directory(work)
            .redirectErrorStream(true)
            .redirectOutput(logFile)
            .start()
        if (!process.waitFor(10, TimeUnit.MINUTES)) {
            process.destroyForcibly()
            error("kptools превысил лимит выполнения 10 минут")
        }
        val output = logFile.takeIf { it.isFile }?.readText()?.takeLast(5000).orEmpty()
        if (output.isNotBlank()) progress(output)
        if (process.exitValue() != 0) {
            error("kptools ${args.first()} завершился с кодом ${process.exitValue()}: ${output.takeLast(1800)}")
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
