package com.nexus.root

import java.io.File
/** Native adapters for already-installed root engines. Never flashes partitions. */
object RootManager {
    enum class Engine { APATCH, KERNELSU, MAGISK, NONE }
    data class Status(val engine: Engine, val detail: String, val hasRoot: Boolean)
    data class CommandResult(val code: Int, val output: String) {
        val ok: Boolean get() = code == 0
    }
    data class Module(val id: String, val name: String, val version: String, val state: String)

    fun detect(): Status {
        val probe = runCatching { shell("id; " +
            "if [ -x /data/adb/ap/bin/apd ] || command -v apd >/dev/null 2>&1; then echo NEXUS_APATCH; " +
            "elif [ -x /data/adb/ksu/bin/ksud ]; then echo NEXUS_KERNELSU; " +
            "elif command -v ksud >/dev/null 2>&1; then echo NEXUS_KERNELSU; " +
            "elif command -v magisk >/dev/null 2>&1; then echo NEXUS_MAGISK; " +
            "elif [ -x /data/adb/magisk/magisk ]; then echo NEXUS_MAGISK; fi") }.getOrNull()
        if (probe == null || !probe.ok || !probe.output.contains("uid=0")) {
            return Status(Engine.NONE, "Root-доступ не подтверждён. Разреши NEXUS ROOT в окне менеджера root.", false)
        }
        val output = probe.output
        val engine = when {
            output.contains("NEXUS_APATCH") -> Engine.APATCH
            output.contains("NEXUS_KERNELSU") -> Engine.KERNELSU
            output.contains("NEXUS_MAGISK") -> Engine.MAGISK
            else -> Engine.NONE
        }
        val label = when (engine) {
            Engine.APATCH -> "APatch: root подтверждён, найден apd"
            Engine.KERNELSU -> "KernelSU: root подтверждён, найден ksud"
            Engine.MAGISK -> "Magisk: root подтверждён, найден magisk"
            Engine.NONE -> "Root есть, но поддерживаемый менеджер не распознан"
        }
        return Status(engine, label, true)
    }

    fun installModule(source: File): CommandResult {
        require(source.isFile && source.length() > 0) { "Файл модуля пуст или отсутствует" }
        require(source.extension.equals("zip", true)) { "Установка модулей пока принимает ZIP-пакеты. APM/KPM не переименовываются в ZIP." }
        val status = detect()
        if (!status.hasRoot || status.engine == Engine.NONE) return CommandResult(1, status.detail)
        val remote = "/data/local/tmp/nexus-module-${System.currentTimeMillis()}.zip"
        val qRemote = quote(remote)
        val qSource = quote(source.absolutePath)
        val installer = when (status.engine) {
            Engine.APATCH -> "APD=\$( [ -x /data/adb/ap/bin/apd ] && echo /data/adb/ap/bin/apd || command -v apd ); \"\$APD\" module install $qRemote"
            Engine.KERNELSU -> "KSU=\$( [ -x /data/adb/ksu/bin/ksud ] && echo /data/adb/ksu/bin/ksud || command -v ksud ); \"\$KSU\" module install $qRemote"
            Engine.MAGISK -> "MAG=\$( command -v magisk || echo /data/adb/magisk/magisk ); \"\$MAG\" --install-module $qRemote"
            Engine.NONE -> error("No root engine")
        }
        return shell("set -e; trap \"rm -f $qRemote\" EXIT; cp $qSource $qRemote; chmod 0644 $qRemote; $installer")
    }

    fun listInstalledModules(): CommandResult = shell(
        "if [ ! -d /data/adb/modules ]; then echo 'Каталог модулей не найден'; exit 0; fi; " +
        "for d in /data/adb/modules/*; do [ -d \"\$d\" ] || continue; " +
        "[ -f \"\$d/module.prop\" ] || continue; " +
        "ID=\$(basename \"\$d\"); NAME=\$(sed -n 's/^name=//p' \"\$d/module.prop\" | head -n 1); " +
        "VER=\$(sed -n 's/^version=//p' \"\$d/module.prop\" | head -n 1); " +
        "[ -e \"\$d/remove\" ] && STATE=Удаляется || ([ -e \"\$d/disable\" ] && STATE=Отключён || STATE=Включён); " +
        "echo \"\$ID|\$NAME|\$VER|\$STATE\"; done"
    )

    fun installedModules(): List<Module> {
        val result = listInstalledModules()
        if (!result.ok) return emptyList()
        return result.output.lineSequence().mapNotNull { line ->
            val parts = line.split('|', limit = 4)
            if (parts.size == 4 && parts[0].matches(Regex("[A-Za-z0-9._-]{1,100}"))) {
                Module(parts[0], parts[1].ifBlank { parts[0] }, parts[2], parts[3])
            } else null
        }.toList()
    }

    fun setModuleEnabled(id: String, enabled: Boolean): CommandResult {
        require(id.matches(Regex("[A-Za-z0-9._-]{1,100}"))) { "Некорректный ID модуля" }
        val status = detect()
        if (!status.hasRoot || status.engine == Engine.NONE) return CommandResult(1, status.detail)
        val command = when (status.engine) {
            Engine.APATCH -> "\"/data/adb/ap/bin/apd\" module ${if (enabled) "enable" else "disable"} ${quote(id)}"
            Engine.KERNELSU -> "\"/data/adb/ksu/bin/ksud\" module ${if (enabled) "enable" else "disable"} ${quote(id)}"
            else -> "D=/data/adb/modules/${quote(id)}; [ -d \"\$D\" ] || exit 4; " +
                if (enabled) "rm -f \"\$D/disable\" \"\$D/remove\"" else "touch \"\$D/disable\""
        }
        return shell(command)
    }

    fun uninstallModule(id: String): CommandResult {
        require(id.matches(Regex("[A-Za-z0-9._-]{1,100}"))) { "Некорректный ID модуля" }
        val status = detect()
        if (!status.hasRoot || status.engine == Engine.NONE) return CommandResult(1, status.detail)
        val command = when (status.engine) {
            Engine.APATCH -> "\"/data/adb/ap/bin/apd\" module uninstall ${quote(id)}"
            Engine.KERNELSU -> "\"/data/adb/ksu/bin/ksud\" module uninstall ${quote(id)}"
            else -> "D=/data/adb/modules/${quote(id)}; [ -d \"\$D\" ] || exit 4; touch \"\$D/remove\""
        }
        return shell(command)
    }

    private fun shell(command: String): CommandResult {
        val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        val output = process.inputStream.bufferedReader().use { it.readText() }.take(12000)
        val code = process.waitFor()
        return CommandResult(code, output.ifBlank { if (code == 0) "OK" else "Команда завершилась с кодом $code" })
    }

    private fun quote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
}
