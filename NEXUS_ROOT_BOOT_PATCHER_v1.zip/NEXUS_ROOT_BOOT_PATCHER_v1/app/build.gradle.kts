plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexus.root"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexus.root"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "1.0"
        ndk { abiFilters += "arm64-v8a" }
        vectorDrawables { useSupportLibrary = true }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug { }
    }
}


dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
}
