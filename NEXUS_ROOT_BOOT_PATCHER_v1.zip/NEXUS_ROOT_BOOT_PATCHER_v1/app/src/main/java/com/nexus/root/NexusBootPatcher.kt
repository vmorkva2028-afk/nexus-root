package com.nexus.root

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** APatch/KernelPatch patch pipeline. Never flashes or modifies a device partition. */
object NexusBootPatcher {
    data class Result(val image: File, val log: String)

    fun patch(context: Context, source: Uri, superKey: String, onLog: (String) -> Unit = {}): Result {
        require(superKey.length in 8..63 && superKey.any(Char::isLetter) && superKey.any(Char::isDigit) && superKey.all { it.isLetterOrDigit() }) {
            "SuperKey must be 8–63 characters, letters and digits only."
        }
        val work = File(context.cacheDir, "nexus-${System.nanoTime()}").apply { mkdirs() }
        val log = StringBuilder()
        fun say(s: String) { log.append(s).append('\n'); onLog(s) }
        try {
            val boot = File(work, "boot.img")
            context.contentResolver.openInputStream(source).use { input ->
                requireNotNull(input) { "Cannot open selected image." }
                FileOutputStream(boot).use { output -> input.copyTo(output) }
            }
            require(boot.length() in (1024L * 1024L)..(1024L * 1024L * 1024L)) { "File size is not plausible for boot.img." }
            require(boot.inputStream().use { input -> val header = ByteArray(8); input.read(header) > 0 }) { "Empty boot image." }

            val kpimg = File(work, "kpimg-android")
            val tool = File(work, "kptools")
            context.assets.open("kpimg-android").use { input -> FileOutputStream(kpimg).use { input.copyTo(it) } }
            context.assets.open("kptools-arm64").use { input -> FileOutputStream(tool).use { input.copyTo(it) } }
            check(tool.setExecutable(true, true)) { "Cannot make kptools executable." }

            fun run(vararg args: String): String {
                val safeArgs = args.mapIndexed { index, value -> if (index > 0 && args[index - 1] == "--skey") "<redacted>" else value }
                say("$ ${safeArgs.joinToString(" ")}")
                val p = ProcessBuilder(listOf(tool.absolutePath) + args).directory(work).redirectErrorStream(true).start()
                val output = p.inputStream.bufferedReader().use { it.readText() }
                if (output.isNotBlank()) say(output.trim())
                val code = p.waitFor()
                check(code == 0) { "kptools exit=$code: ${args.joinToString(" ")}" }
                return output
            }

            say("1/4 Unpacking boot.img")
            run("unpack", boot.name)
            val kernel = File(work, "kernel")
            require(kernel.isFile && kernel.length() > 1024L * 1024L) { "Kernel payload not found. This image format may not be supported by this kptools build." }
            val kernelBackup = File(work, "kernel-b")
            kernel.copyTo(kernelBackup, overwrite = true)

            say("2/4 Checking kernel configuration")
            val config = run("-f", "--image", kernelBackup.name)
            require(Regex("CONFIG_KALLSYMS=y").containsMatchIn(config)) {
                "Target kernel does not report CONFIG_KALLSYMS=y; APatch cannot safely patch it."
            }

            say("3/4 Applying KernelPatch (APatch core)")
            run("-p", "--image", kernelBackup.name, "--skey", superKey, "--kpimg", kpimg.name, "--out", "kernel")
            val patchedKernel = File(work, "kernel")
            require(patchedKernel.isFile && patchedKernel.length() > 1024L * 1024L) { "Patched kernel was not produced." }

            say("4/4 Repacking boot image")
            run("repack", boot.name)
            val output = File(work, "new-boot.img")
            require(output.isFile && output.length() > 1024L * 1024L) { "Repacked new-boot.img was not produced." }
            val retained = File(context.cacheDir, "NEXUS-APATCH-${System.currentTimeMillis()}-boot.img")
            output.copyTo(retained, overwrite = true)
            say("SUCCESS: ${retained.name}")
            return Result(retained, log.toString())
        } catch (t: Throwable) {
            say("FAILED: ${t.message ?: t.javaClass.simpleName}")
            throw IllegalStateException(log.toString(), t)
        } finally {
            work.deleteRecursively()
        }
    }
}
