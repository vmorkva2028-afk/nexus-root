package com.nexus.root

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileInputStream

class MainActivity : ComponentActivity() {
    private var bootUri: Uri? = null
    private var patched: java.io.File? = null
    private lateinit var status: TextView
    private lateinit var key: EditText
    private lateinit var patchButton: Button

    private val pickBoot = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            bootUri = uri
            status.text = "Выбран boot.img. Проверь, что это именно boot-раздел твоей прошивки."
        }
    }
    private val savePatched = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val file = patched
        if (uri != null && file != null) {
            contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(file).use { it.copyTo(out) } }
            status.text = "Готово. Пропатченный образ сохранён. Оригинал не изменялся."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (resources.displayMetrics.density * 18).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad,pad,pad,pad); setBackgroundColor(0xFF101116.toInt()) }
        fun label(text: String, size: Float = 16f) = TextView(this).apply { this.text=text; textSize=size; setTextColor(0xFFF2F2F7.toInt()); setPadding(0,pad/2,0,pad/2) }
        root.addView(label("NEXUS ROOT", 26f))
        root.addView(label("APatch / KernelPatch • ARM64", 14f))
        root.addView(label("Патчинг выполняется локально на телефоне. Прошивка разделов автоматически не выполняется."))
        root.addView(Button(this).apply { text="ВЫБРАТЬ BOOT.IMG"; setOnClickListener { pickBoot.launch(arrayOf("application/octet-stream", "*/*")) } })
        key = EditText(this).apply { hint="SuperKey (8–63 буквы и цифры)"; setSingleLine(true); setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFAAAAAA.toInt()) }
        root.addView(key)
        patchButton = Button(this).apply { text="PATCH BOOT IMAGE"; setOnClickListener { startPatch() } }
        root.addView(patchButton)
        root.addView(Button(this).apply { text="СОХРАНИТЬ ПРОПАТЧЕННЫЙ IMG"; setOnClickListener { patched?.let { savePatched.launch(it.name) } ?: run { status.text="Сначала выполни патчинг." } } })
        status = label("Ожидание файла…", 13f)
        root.addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun startPatch() {
        val uri = bootUri ?: run { status.text="Сначала выбери boot.img."; return }
        val secret = key.text.toString()
        if (secret.length !in 8..63 || secret.none(Char::isLetter) || secret.none(Char::isDigit) || secret.any { !it.isLetterOrDigit() }) {
            status.text="SuperKey: 8–63 символа, только буквы и цифры."; return
        }
        patchButton.isEnabled = false
        status.text="Патчинг запущен… Не закрывай приложение."
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { NexusBootPatcher.patch(this@MainActivity, uri, secret) }
                patched = result.image
                status.text="Патчинг завершён. ${result.image.name}\nНажми «СОХРАНИТЬ», чтобы экспортировать файл."
            } catch (e: Exception) {
                status.text="Ошибка патчинга:\n${e.message ?: e.javaClass.simpleName}"
            } finally { patchButton.isEnabled = true }
        }
    }
}
