package com.nexus.root

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * APatch/KernelPatch boot-image patch pipeline.
 * Uses the official KernelPatch kptools CLI and kpimg-android built by CI.
 * It writes a separate new-boot.img and never flashes a device partition.
 */
class ApPatchEngine(private val context: Context) {
    data class Result(val output: File, val log: String)

    fun patch(
        bootUri: Uri,
        superKey: String,
        progress: (String) -> Unit = {}
    ): Result {
        require(superKey.length in 8..63 && superKey.all { it.isLetterOrDigit() }) {
            "APatch SuperKey: требуется 8–63 буквы или цифры"
        }
        require(android.os.Build.SUPPORTED_ABIS.any { it == "arm64-v8a" }) {
            "Эта сборка NEXUS ROOT содержит kptools только для ARM64"
        }

        val work = File(context.cacheDir, "nexus-apatch-${System.currentTimeMillis()}").apply { mkdirs() }
        val boot = copyUri(bootUri, File(work, "boot.img"))
        require(boot.length() > 4096) { "Выбранный файл слишком маленький для boot.img" }
        require(hasAndroidBootMagic(boot)) {
            "Не найден заголовок ANDROID! Это должен быть исходный boot.img, не vendor_boot.img и не init_boot.img"
        }

        val tool = File(context.applicationInfo.nativeLibraryDir, "libkptools.so")
        require(tool.isFile && tool.canExecute()) {
            "В APK отсутствует исполняемый ARM64 kptools. Пересобери APK через GitHub Actions с KernelPatch tools."
        }

        val kpimg = File(work, "kpimg-android")
        context.assets.open("kpimg-android").use { input ->
            kpimg.outputStream().use { output -> input.copyTo(output) }
        }
        require(kpimg.isFile && kpimg.length() > 4096) {
            "В APK отсутствует настоящий kpimg-android или файл повреждён"
        }

        val log = mutableListOf<String>()
        fun report(message: String) {
            log += message
            progress(message.take(1200))
        }

        report("Проверка KernelPatch kptools…")
        val help = runTool(work, tool, listOf("--help"), superKey, allowNonZero = true)
        require(help.isNotBlank()) { "kptools не запустился или не вывел справку" }

        report("Распаковка исходного boot.img…")
        runTool(work, tool, listOf("unpack", boot.name), superKey)

        // Official kptools unpack emits a file named `kernel`; keep a separate
        // `kernel-b` input because this is the documented APatch patch sequence.
        val unpacked = listOf(File(work, "kernel"), File(work, "kernel-b"))
            .firstOrNull { it.isFile && it.length() > 4096 }
            ?: error("kptools unpack не создал kernel. Формат boot.img может не поддерживаться.")
        val kernelOriginal = File(work, "kernel-b")
        if (unpacked != kernelOriginal) {
            if (kernelOriginal.exists()) kernelOriginal.delete()
            unpacked.copyTo(kernelOriginal, overwrite = true)
        }
        require(kernelOriginal.length() > 4096) { "Извлечённое ядро пустое или повреждено" }

        report("Патчинг ядра APatch / KernelPatch…")
        runTool(
            work,
            tool,
            listOf("-p", "--image", kernelOriginal.name, "--skey", superKey,
                "--kpimg", kpimg.name, "--out", "kernel"),
            superKey
        )
        val patchedKernel = File(work, "kernel")
        require(patchedKernel.isFile && patchedKernel.length() > 4096) {
            "kptools завершился без ошибки, но пропатченное ядро не создано"
        }

        report("Пересборка boot.img с сохранением исходных компонентов…")
        runTool(work, tool, listOf("repack", boot.name), superKey)
        val output = File(work, "new-boot.img")
        require(output.isFile && output.length() > 4096) {
            "kptools repack не создал new-boot.img"
        }
        require(hasAndroidBootMagic(output)) {
            "Полученный файл не имеет корректной сигнатуры Android boot image"
        }

        val hash = sha256(output)
        report("Патчинг завершён. SHA-256: $hash")
        return Result(
            output,
            "APatch / KernelPatch: boot.img распакован, ядро пропатчено и образ пересобран.\n" +
                "Размер: ${output.length()} байт\nSHA-256: $hash\n\n" + log.joinToString("\n")
        )
    }

    private fun copyUri(uri: Uri, target: File): File {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Не удалось открыть выбранный файл" }
            target.outputStream().use { output -> input.copyTo(output) }
        }
        return target
    }

    private fun hasAndroidBootMagic(file: File): Boolean =
        file.inputStream().use { input ->
            val magic = ByteArray(8)
            input.read(magic) == 8 && magic.contentEquals("ANDROID!".toByteArray(Charsets.US_ASCII))
        }

    private fun runTool(
        work: File,
        tool: File,
        args: List<String>,
        secret: String,
        allowNonZero: Boolean = false
    ): String {
        val logFile = File(work, "kptools-${System.nanoTime()}.log")
        val process = ProcessBuilder(listOf(tool.absolutePath) + args)
            .directory(work)
            .redirectErrorStream(true)
            .redirectOutput(logFile)
            .start()
        if (!process.waitFor(5, TimeUnit.MINUTES)) {
            process.destroyForcibly()
            error("kptools превысил лимит времени (5 минут): ${args.firstOrNull()}")
        }
        val raw = if (logFile.isFile) logFile.readText(Charsets.UTF_8) else ""
        val safeOutput = raw.replace(secret, "[SUPERKEY HIDDEN]")
        if (process.exitValue() != 0 && !allowNonZero) {
            error("kptools ${args.firstOrNull()} завершился с кодом ${process.exitValue()}: ${safeOutput.takeLast(2500)}")
        }
        if (process.exitValue() == 0 && safeOutput.isNotBlank()) {
            // Keep command output available in the final operation report without exposing the key.
        }
        return safeOutput
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
