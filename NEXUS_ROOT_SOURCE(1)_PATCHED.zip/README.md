# NEXUS ROOT v0.7 — APatch Boot Image Patcher

## Что включено

- Android-приложение на Kotlin/Jetpack Compose.
- Реальный CLI-пайплайн на базе официальных `kpimg-android` и `kptools` проекта KernelPatch.
- Сборка ARM64 `kptools` под Android NDK и Android-варианта `kpimg` в GitHub Actions.
- Выбор исходного `boot.img`, распаковка, патчинг ядра с APatch SuperKey и пересборка `new-boot.img`.
- Проверка Android boot magic и SHA-256 результата.
- Сохранение отдельного пропатченного файла; автоматическая запись в разделы устройства не выполняется.

## GitHub Actions

Положи этот архив в корень репозитория под точным именем `NEXUS_ROOT_SOURCE(1).zip`. Файл workflow должен находиться в `.github/workflows/build-apk.yml`.

Запусти Actions → Build NEXUS ROOT APatch APK → Run workflow. В артефакте будут APK, контрольные суммы бинарников и BUILD-INFO.

Сборка использует официальный KernelPatch tag `0.13.9`, чтобы версии `kpimg` и `kptools` совпадали. В APK включаются только ARM64-инструменты; приложение требует ARM64-устройство и Android API 26+.

## Использование

1. Получи оригинальный `boot.img` именно от установленной на устройстве прошивки.
2. В NEXUS ROOT открой «Патчинг» и выбери `boot.img`.
3. Введи APatch SuperKey (8–63 буквы/цифры).
4. Нажми «НАСТОЯЩИЙ APATCH BOOT PATCH» и дождись завершения.
5. Сохрани `nexus-patched-boot.img`.

Не прошивай образ, пока не проверены совместимость с конкретной моделью/ядром и способ восстановления. Успешное выполнение `kptools` не гарантирует, что ядро конкретного устройства загрузится с патчем. Сохрани оригинальный boot.img и заранее подготовь штатный способ восстановления.

## Ограничения текущей версии

- Поддерживается входной Android `boot.img` с сигнатурой `ANDROID!`; `vendor_boot.img` и `init_boot.img` не принимаются.
- В приложение встроен ARM64 backend; x86/x86_64 устройства не поддерживаются.
- Прошивка разделов, разблокировка bootloader и установка root не выполняются приложением.
- Каталог модулей пока служит для импорта/хранения; установка KPM/APM ещё не подключена.
- APK собирается как debug APK и подписывается debug-ключом Gradle.

## Источники и лицензия

KernelPatch: https://github.com/bmax121/KernelPatch
Build instructions: https://github.com/bmax121/KernelPatch/blob/0.13.9/doc/en/build.md
KernelPatch распространяется под GPL-2.0; соответствующая лицензия включается в assets APK.
