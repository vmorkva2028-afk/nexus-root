# NEXUS ROOT v0.7 — APatch ARM64 patch pipeline

Android-приложение для патча `boot.img` через официальные бинарники KernelPatch (APatch).

## Что внутри

- UI на Jetpack Compose
- `ApPatchEngine` — unpack → patch (`-p`) → repack
- **Gradle Wrapper 8.9** (`gradlew`, `gradlew.bat`, `gradle/wrapper/`) — уже в архиве, отдельно ставить Gradle не нужно
- В APK CI кладёт:
  - `assets/kpimg-android` — релиз KernelPatch
  - `jniLibs/arm64-v8a/libkptools.so` — Android ARM64 `kptools`

Приложение **не прошивает** разделы. На выходе только `nexus-patched-boot.img`.

## Сборка через GitHub Actions

1. В корне репозитория положи этот архив как `NEXUS_ROOT_SOURCE.zip`.
2. Положи workflow в `.github/workflows/build-apk.yml`.
3. Push в `main` или **Actions → Build NEXUS ROOT APatch APK → Run workflow**.
4. Скачай артефакт `NEXUS-ROOT-v0.7-APatch-ARM64`.

Workflow качает `kpimg-android` и `kptools-android` с [релизов KernelPatch](https://github.com/bmax121/KernelPatch/releases) (как официальный APatch) и собирает APK через `./gradlew`.

Версия KernelPatch: env `KERNELPATCH_VERSION` в workflow (сейчас `0.13.9`).
AGP `8.7.3` + Gradle Wrapper `8.9`.

## Локально

Нужны JDK 17 и Android SDK 35 (`ANDROID_HOME` или `local.properties` → `sdk.dir`).

```bash
chmod +x ./gradlew
./gradlew assembleDebug
```

Бинарники KernelPatch workflow скачивает сам. Для локальной сборки с рабочим патчером положи:

- `app/src/main/assets/kpimg-android`
- `app/src/main/jniLibs/arm64-v8a/libkptools.so`

с [релиза KernelPatch](https://github.com/bmax121/KernelPatch/releases/tag/0.13.9).

## Использование на телефоне

1. ARM64, разблокированный bootloader.
2. Ядро с `CONFIG_KALLSYMS=y`.
3. Оригинальный **boot.img** (не init_boot / vendor_boot).
4. SuperKey: 8–63 символа, только буквы и цифры.
5. Патч → сохрани `nexus-patched-boot.img` → прошей через fastboot:

```bash
fastboot flash boot nexus-patched-boot.img
fastboot reboot
```

## Ограничения v0.7

- Только ARM64
- Только файловый патч boot.img
- Нет автопрошивки, KernelSU/Magisk, runtime KPM/APM

## Upstream

- KernelPatch: https://github.com/bmax121/KernelPatch
- APatch install: https://apatch.dev/install.html

KernelPatch — GPL-2.0. Сохраняй лицензии при распространении.
