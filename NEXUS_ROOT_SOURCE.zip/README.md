# NEXUS ROOT v0.4

Android Studio project for the NEXUS ROOT application shell.

## Build APK without tests

This repository includes a GitHub Actions workflow. Push the project to a GitHub repository and run **Actions → Build NEXUS ROOT APK**. The workflow executes only:

`gradle :app:assembleDebug`

It does not run unit tests or instrumentation tests.

The APK artifact is uploaded as `NEXUS-ROOT-debug-apk`.

## Current implementation

- Jetpack Compose dark interface
- Dashboard with device and Android information
- Installation screen with Android document picker
- Module manager placeholder for NEXUS/APM/KPM
- Device diagnostics screen
- GitHub Actions APK build workflow

## Important status

This is an application shell, not a working root solution yet. Boot image parsing and patching, the NEXUS privilege escalation engine, module runtime, Direct Patch, AVB handling, and flashing are not implemented. The file picker only selects a file; it does not modify it. No tests are run by the workflow.
