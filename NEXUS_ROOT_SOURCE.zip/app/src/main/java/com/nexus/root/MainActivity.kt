package com.nexus.root

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080D16)
private val Panel = Color(0xFF111B2A)
private val Blue = Color(0xFF39A9FF)
private val Muted = Color(0xFF91A2B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

@Composable
fun NexusApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selectedFile by remember { mutableStateOf("Файл не выбран") }
    var notice by remember { mutableStateOf("NEXUS ROOT готов к настройке") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            selectedFile = uri.lastPathSegment ?: uri.toString()
            notice = "Образ выбран. Анализ и патчинг ещё разрабатываются."
        }
    }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, background = Bg, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    val labels = listOf("Главная", "Установка", "Модули", "Инструменты")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Build, Icons.Default.Extension, Icons.Default.Tune)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Blue, selectedTextColor = Blue,
                                indicatorColor = Color(0xFF193653),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> HomeScreen(onInstall = { tab = 1 }, onModules = { tab = 2 })
                    1 -> InstallScreen(selectedFile, notice, onPick = { picker.launch(arrayOf("*/*")) })
                    2 -> ModulesScreen()
                    else -> ToolsScreen()
                }
            }
        }
    }
}

@Composable
fun Header(subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("NEXUS ROOT", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        content = content
    )
}

@Composable
fun HomeScreen(onInstall: () -> Unit, onModules: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Header("UNIVERSAL ANDROID ROOT PLATFORM  •  v0.4") }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                PanelCard {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, null, tint = Blue, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Состояние системы", fontWeight = FontWeight.SemiBold)
                                Text("Root Engine пока не установлен", color = Muted, fontSize = 12.sp)
                            }
                        }
                        Divider(color = Color(0xFF26364B))
                        Text("Это версия разработки. Приложение пока не предоставляет Root-доступ.", color = Muted, fontSize = 12.sp)
                    }
                }
                PanelCard {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Устройство", fontWeight = FontWeight.Bold)
                        InfoLine("Модель", "${Build.MANUFACTURER} ${Build.MODEL}")
                        InfoLine("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                        InfoLine("Архитектура", Build.SUPPORTED_ABIS.firstOrNull() ?: "Не определена")
                        InfoLine("Процессор ABI", Build.SUPPORTED_ABIS.joinToString())
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    QuickCard("Установка", "Patch File / Direct Patch", Icons.Default.Build, Modifier.weight(1f), onInstall)
                    QuickCard("Модули", "NEXUS / APM / KPM", Icons.Default.Extension, Modifier.weight(1f), onModules)
                }
                Text("Поддерживаемые направления", color = Muted, fontSize = 12.sp)
                PanelCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoLine("Архитектуры", "ARM64 · ARM32 · x86 · x86_64")
                        InfoLine("Ядра", "GKI · Non-GKI")
                        InfoLine("Модули", "NEXUS · APM · KPM")
                        InfoLine("Методы", "Patch File · Direct Patch")
                    }
                }
            }
        }
    }
}

@Composable
fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.width(12.dp))
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun QuickCard(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    PanelCard {
        Column(modifier.clickable(onClick = onClick).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Blue)
            Text(title, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun InstallScreen(selectedFile: String, notice: String, onPick: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Header("Установка и подготовка образов") }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                PanelCard {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("PATCH FILE", color = Blue, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Text("Выбери загрузочный образ для будущей обработки.", color = Muted, fontSize = 12.sp)
                        OutlinedButton(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.FolderOpen, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Выбрать boot-образ")
                        }
                        Text(selectedFile, color = Color.White, fontSize = 12.sp)
                        Text("Поддерживаемые типы: boot.img, init_boot.img, vendor_boot.img", color = Muted, fontSize = 11.sp)
                        Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) {
                            Text("ПАТЧИНГ БУДЕТ ДОБАВЛЕН ПОЗЖЕ")
                        }
                    }
                }
                PanelCard {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("DIRECT PATCH", color = Blue, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Text("Автоматическое определение устройства и подготовка образа.", color = Muted, fontSize = 12.sp)
                        OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) {
                            Text("Скоро")
                        }
                    }
                }
                Text(notice, color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun ModulesScreen() {
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Header("Менеджер модулей") }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(
                    Triple("NEXUS Modules", "Собственный формат модулей платформы", "В разработке"),
                    Triple("APM Compatibility", "Совместимость с форматом APM", "Планируется"),
                    Triple("KPM Compatibility", "Совместимость с KernelPatch-модулями", "Планируется")
                ).forEach { (name, description, state) ->
                    PanelCard {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Extension, null, tint = Blue)
                                Spacer(Modifier.width(10.dp))
                                Text(name, fontWeight = FontWeight.Bold)
                            }
                            Text(description, color = Muted, fontSize = 12.sp)
                            Text(state, color = Blue, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolsScreen() {
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Header("Инструменты и диагностика") }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PanelCard {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Сведения об Android", fontWeight = FontWeight.Bold)
                        InfoLine("Производитель", Build.MANUFACTURER)
                        InfoLine("Модель", Build.MODEL)
                        InfoLine("Устройство", Build.DEVICE)
                        InfoLine("Продукт", Build.PRODUCT)
                        InfoLine("Версия Android", Build.VERSION.RELEASE)
                        InfoLine("SDK", Build.VERSION.SDK_INT.toString())
                        InfoLine("ABI", Build.SUPPORTED_ABIS.joinToString())
                    }
                }
                PanelCard {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Статус компонентов", fontWeight = FontWeight.Bold)
                        InfoLine("NEXUS Root Engine", "Не реализован")
                        InfoLine("Boot image parser", "Не реализован")
                        InfoLine("Direct Patch", "Не реализован")
                        InfoLine("Module runtime", "Не реализован")
                    }
                }
            }
        }
    }
}
